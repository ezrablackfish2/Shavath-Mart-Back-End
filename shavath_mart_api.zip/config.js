module.exports = {
  development: {
    username: 'ezra',
    password: 'tutu@12345',
    database: 'ezra',
    host: 'localhost',
    dialect: 'mysql',
  },
};

